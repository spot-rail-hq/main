// Logo components for SpotRail HQ — 10 variations
// Style: modern, tech, clean, minimal. UK trainspotting.

const BRAND = {
  ink: '#0B1B2B',
  ink2: '#13304A',
  paper: '#FAFAF7',
  paperWarm: '#F3EFE7',
  signal: '#E63946',    // signal red
  live: '#00C389',       // "live" green
  rail: '#8A97A6',       // steel
  amber: '#F4A524',
};

// ── Small building blocks ─────────────────────────────────────────────

// A tiny pin/dot used for the "spot" motif
function LiveDot({ size = 8, color = BRAND.signal, pulse = false }) {
  return (
    <span style={{
      display: 'inline-block', width: size, height: size, borderRadius: '50%',
      background: color, verticalAlign: 'middle',
      boxShadow: pulse ? `0 0 0 3px ${color}22` : 'none',
    }} />
  );
}

// SVG: two parallel rails (plan view) with ties
function RailsIcon({ w = 56, h = 28, color = BRAND.ink, stroke = 2 }) {
  return (
    <svg width={w} height={h} viewBox="0 0 56 28" fill="none">
      <line x1="0" y1="9" x2="56" y2="9" stroke={color} strokeWidth={stroke} />
      <line x1="0" y1="19" x2="56" y2="19" stroke={color} strokeWidth={stroke} />
      {[6, 18, 30, 42].map(x => (
        <line key={x} x1={x} y1="4" x2={x} y2="24" stroke={color} strokeWidth={stroke} />
      ))}
    </svg>
  );
}

// ── Logo 01: Monogram SR in rounded square + wordmark ─────────────────
function Logo01() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
      <svg width="52" height="52" viewBox="0 0 52 52">
        <rect width="52" height="52" rx="12" fill={BRAND.ink} />
        <text x="26" y="34" textAnchor="middle"
              fontFamily="Inter, sans-serif" fontWeight="700" fontSize="22"
              fill={BRAND.paper} letterSpacing="-0.5">SR</text>
        <circle cx="40" cy="13" r="3.5" fill={BRAND.signal} />
      </svg>
      <div style={{ fontFamily: 'Inter, sans-serif', lineHeight: 1 }}>
        <div style={{ fontSize: 22, fontWeight: 600, color: BRAND.ink, letterSpacing: -0.6 }}>
          SpotRail <span style={{ color: BRAND.signal }}>HQ</span>
        </div>
        <div style={{ fontSize: 10.5, fontWeight: 500, color: BRAND.rail,
                      letterSpacing: 2.2, marginTop: 6, textTransform: 'uppercase' }}>
          UK trainspotting, live
        </div>
      </div>
    </div>
  );
}

// ── Logo 02: Hyphenated "Spot-Rail" with signal dot over the i ────────
function Logo02() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <svg width="44" height="44" viewBox="0 0 44 44">
        <circle cx="22" cy="22" r="21" stroke={BRAND.ink} strokeWidth="2" fill="none" />
        <circle cx="22" cy="22" r="4" fill={BRAND.signal} />
        <circle cx="22" cy="22" r="10" stroke={BRAND.signal} strokeWidth="1.5" fill="none" opacity="0.5" />
      </svg>
      <div style={{ fontFamily: 'Inter, sans-serif',
                    fontSize: 26, fontWeight: 500, color: BRAND.ink,
                    letterSpacing: -0.8, lineHeight: 1 }}>
        Spot<span style={{ color: BRAND.rail }}>-</span>Rail
        <span style={{ fontWeight: 700, marginLeft: 8, color: BRAND.ink }}>HQ</span>
      </div>
    </div>
  );
}

// ── Logo 03: Terminal / console style ─────────────────────────────────
function Logo03() {
  return (
    <div style={{
      fontFamily: '"IBM Plex Mono", ui-monospace, monospace',
      fontSize: 20, fontWeight: 500, color: BRAND.ink,
      display: 'inline-flex', alignItems: 'center', gap: 2,
      padding: '10px 14px',
      background: BRAND.paperWarm,
      border: `1.5px solid ${BRAND.ink}`,
      letterSpacing: -0.3,
    }}>
      <span style={{ color: BRAND.signal, marginRight: 6 }}>▸</span>
      spot<span style={{ color: BRAND.rail }}>_</span>rail
      <span style={{ marginLeft: 8, background: BRAND.ink, color: BRAND.paper,
                     padding: '2px 6px', fontSize: 14 }}>HQ</span>
      <span style={{ marginLeft: 6, width: 9, height: 18, background: BRAND.ink,
                     display: 'inline-block', animation: 'srhq-blink 1s steps(2) infinite' }} />
      <style>{`@keyframes srhq-blink{50%{opacity:0}}`}</style>
    </div>
  );
}

// ── Logo 04: Pin + wordmark (location-first) ──────────────────────────
function Logo04() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <svg width="32" height="44" viewBox="0 0 32 44">
        <path d="M16 2 C7 2 2 9 2 17 C2 27 16 42 16 42 C16 42 30 27 30 17 C30 9 25 2 16 2 Z"
              fill={BRAND.ink} />
        {/* small rail tracks in the pin head */}
        <line x1="8" y1="14" x2="24" y2="14" stroke={BRAND.paper} strokeWidth="1.6" />
        <line x1="8" y1="20" x2="24" y2="20" stroke={BRAND.paper} strokeWidth="1.6" />
        <line x1="12" y1="11" x2="12" y2="23" stroke={BRAND.paper} strokeWidth="1.6" />
        <line x1="20" y1="11" x2="20" y2="23" stroke={BRAND.paper} strokeWidth="1.6" />
      </svg>
      <div style={{ fontFamily: '"Space Grotesk", Inter, sans-serif',
                    fontSize: 26, fontWeight: 600, color: BRAND.ink,
                    letterSpacing: -1, lineHeight: 1 }}>
        SpotRail<span style={{ color: BRAND.signal }}>.</span>hq
      </div>
    </div>
  );
}

// ── Logo 05: Dot-matrix departure board ───────────────────────────────
function Logo05() {
  // Dot-matrix glyphs are expensive to hand-draw; use a departure-board
  // frame around real type for the same effect, cheaper and legible.
  return (
    <div style={{
      background: BRAND.ink, padding: '10px 16px',
      borderRadius: 4, display: 'inline-flex', alignItems: 'center', gap: 12,
      fontFamily: 'Inter, sans-serif',
    }}>
      <div style={{ display: 'flex', gap: 3 }}>
        {[0,1,2].map(i => (
          <span key={i} style={{ width: 5, height: 5, borderRadius: '50%',
                                  background: BRAND.amber,
                                  opacity: 1 - i * 0.35 }} />
        ))}
      </div>
      <div style={{ fontSize: 20, fontWeight: 600, color: BRAND.amber,
                    letterSpacing: 1, fontVariantNumeric: 'tabular-nums' }}>
        SPOTRAIL · HQ
      </div>
    </div>
  );
}

// ── Logo 06: Rails-through-text (horizon rails) ───────────────────────
function Logo06() {
  return (
    <div style={{ display: 'inline-flex', flexDirection: 'column', alignItems: 'flex-start',
                  fontFamily: 'Inter, sans-serif', gap: 6 }}>
      <div style={{ fontSize: 26, fontWeight: 700, color: BRAND.ink,
                    letterSpacing: -0.9, lineHeight: 1 }}>
        Spot<span style={{ fontWeight: 400, color: BRAND.rail }}>/</span>Rail
        <span style={{ color: BRAND.signal, marginLeft: 6 }}>HQ</span>
      </div>
      <RailsIcon w={190} h={14} color={BRAND.ink} stroke={1.4} />
    </div>
  );
}

// ── Logo 07: Circular "LIVE" badge mark ───────────────────────────────
function Logo07() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <div style={{
        width: 52, height: 52, borderRadius: '50%',
        background: BRAND.paper, border: `2px solid ${BRAND.ink}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative',
      }}>
        <svg width="30" height="30" viewBox="0 0 30 30">
          {/* stylised track converging */}
          <path d="M4 26 L13 6 L17 6 L26 26" stroke={BRAND.ink} strokeWidth="2" fill="none" strokeLinecap="round" />
          <line x1="9" y1="17" x2="21" y2="17" stroke={BRAND.ink} strokeWidth="1.6" />
          <line x1="11" y1="12" x2="19" y2="12" stroke={BRAND.ink} strokeWidth="1.6" />
        </svg>
        <span style={{
          position: 'absolute', top: -2, right: -2,
          width: 14, height: 14, borderRadius: '50%', background: BRAND.live,
          border: `2px solid ${BRAND.paper}`,
        }} />
      </div>
      <div style={{ fontFamily: '"Space Grotesk", sans-serif', lineHeight: 1 }}>
        <div style={{ fontSize: 22, fontWeight: 600, color: BRAND.ink, letterSpacing: -0.5 }}>
          SpotRail HQ
        </div>
        <div style={{ fontSize: 10, color: BRAND.live, fontWeight: 700,
                      letterSpacing: 2, marginTop: 5 }}>
          ● LIVE · UK RAIL
        </div>
      </div>
    </div>
  );
}

// ── Logo 08: Bracketed / codebase feel ────────────────────────────────
function Logo08() {
  return (
    <div style={{
      fontFamily: '"Space Grotesk", Inter, sans-serif',
      fontSize: 26, fontWeight: 500, color: BRAND.ink,
      letterSpacing: -0.7, display: 'inline-flex', alignItems: 'baseline', gap: 4,
    }}>
      <span style={{ color: BRAND.rail, fontWeight: 300 }}>[</span>
      spot<span style={{ color: BRAND.signal }}>·</span>rail
      <span style={{ color: BRAND.rail, fontWeight: 300 }}>]</span>
      <span style={{ fontWeight: 700, marginLeft: 2 }}>hq</span>
    </div>
  );
}

// ── Logo 09: Front-of-train silhouette mark (Class 377-ish geometry) ──
function Logo09() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <svg width="54" height="44" viewBox="0 0 54 44">
        {/* simplified modern EMU front — rounded nose, cab window, skirt */}
        <path d="M6 40 L6 20 C6 10 14 4 27 4 C40 4 48 10 48 20 L48 40 Z"
              fill={BRAND.ink} />
        <rect x="12" y="14" width="30" height="10" rx="2" fill={BRAND.paper} />
        <rect x="14" y="30" width="8" height="4" fill={BRAND.signal} />
        <rect x="32" y="30" width="8" height="4" fill={BRAND.paper} />
      </svg>
      <div style={{ fontFamily: 'Inter, sans-serif', lineHeight: 1 }}>
        <div style={{ fontSize: 22, fontWeight: 700, color: BRAND.ink, letterSpacing: -0.6 }}>
          SpotRail<span style={{ fontWeight: 400 }}> HQ</span>
        </div>
        <div style={{ fontSize: 10, color: BRAND.rail, fontWeight: 500,
                      letterSpacing: 1.6, marginTop: 4, textTransform: 'uppercase' }}>
          Spot · Track · Share
        </div>
      </div>
    </div>
  );
}

// ── Logo 10: Station-sign "roundel" style (UK vibe) ───────────────────
function Logo10() {
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'stretch',
      border: `2px solid ${BRAND.ink}`, borderRadius: 6, overflow: 'hidden',
      fontFamily: 'Inter, sans-serif',
    }}>
      <div style={{ background: BRAND.ink, color: BRAND.paper,
                    padding: '10px 12px', display: 'flex', alignItems: 'center', gap: 6 }}>
        <span style={{ width: 10, height: 10, borderRadius: '50%', background: BRAND.signal,
                       boxShadow: `0 0 0 3px ${BRAND.signal}33` }} />
        <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: 2 }}>HQ</span>
      </div>
      <div style={{ padding: '10px 16px', display: 'flex', alignItems: 'center',
                    fontSize: 22, fontWeight: 600, color: BRAND.ink, letterSpacing: -0.5 }}>
        Spot<span style={{ color: BRAND.rail, margin: '0 1px' }}>·</span>Rail
      </div>
    </div>
  );
}

Object.assign(window, {
  BRAND,
  Logo01, Logo02, Logo03, Logo04, Logo05,
  Logo06, Logo07, Logo08, Logo09, Logo10,
});
