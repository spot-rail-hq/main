// SpotRail HQ — horizontal logos on dark, turquoise primary.
// Mark concept follows the user's reference: an "S" ribbon, a train nose,
// and rail ties. Each option remixes that trio at a different ratio.

const T = {
  bg: '#0B1220',           // near-black navy
  bgAlt: '#0E1826',
  turq: '#40E0D0',         // user-specified primary
  turqDim: '#2BB5A8',
  ink: '#E8F3F2',          // warm white
  steel: '#8AA0B4',
  steelDim: '#5A6B7D',
  ember: '#FF6B57',        // reserved accent (live / alerts)
};

// ─── Mark primitives ─────────────────────────────────────────────────

// The S-ribbon: two stacked "rails" forming an S, with a clean terminus
// that morphs into a train nose on the top-right.
function SRibbon({ size = 72, stroke = 10, color = T.turq, ties = true }) {
  // 72-unit canvas. The S is a double-stroke path; the top stroke extends
  // into a train silhouette.
  const r = stroke / 2;
  return (
    <svg width={size} height={size} viewBox="0 0 72 72" fill="none">
      {/* bottom rail of the S */}
      <path
        d="M 58 22 C 58 14, 48 10, 38 10 L 24 10 C 14 10, 8 16, 8 24 C 8 32, 14 36, 24 36 L 48 36 C 58 36, 64 40, 64 48 C 64 56, 58 62, 48 62 L 18 62"
        stroke={color} strokeWidth={stroke} strokeLinecap="round"
      />
      {/* train nose sitting on the top-right terminus of the S */}
      <g>
        <path
          d="M 44 6 L 44 18 C 44 22 48 24 52 24 L 62 24 C 66 24 68 21 68 17 C 68 12 64 6 58 6 Z"
          fill={color}
        />
        {/* cab window */}
        <path d="M 48 10 L 58 10 C 60 10 62 11 63 13 L 52 13 C 50 13 48 12 48 10 Z" fill={T.bg} />
        {/* headlight */}
        <circle cx="65" cy="20" r="1.6" fill={T.bg} />
      </g>
      {ties && (
        <g stroke={color} strokeWidth="2.4" strokeLinecap="round">
          <line x1="10" y1="68" x2="16" y2="62" />
          <line x1="22" y1="68" x2="28" y2="62" />
          <line x1="34" y1="68" x2="40" y2="62" />
          <line x1="46" y1="68" x2="52" y2="62" />
        </g>
      )}
    </svg>
  );
}

// A tighter, fully geometric S-mark (for variants that want less train, more S)
function SGeo({ size = 64, color = T.turq, dotColor = T.turq }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      <path
        d="M 54 20 C 54 13, 47 8, 38 8 L 22 8 C 14 8, 8 14, 8 22 C 8 30, 14 34, 22 34 L 42 34 C 50 34, 56 40, 56 48 C 56 55, 50 60, 42 60 L 14 60"
        stroke={color} strokeWidth="9" strokeLinecap="round"
      />
      <circle cx="54" cy="12" r="4" fill={dotColor} />
    </svg>
  );
}

// Just the train nose (front 3/4 view, simplified)
function TrainNose({ size = 56, color = T.turq, accent = T.bg }) {
  return (
    <svg width={size * 1.15} height={size} viewBox="0 0 64 56" fill="none">
      <path
        d="M 6 50 L 6 28 C 6 16 16 8 32 8 C 46 8 56 16 58 28 L 58 50 Z"
        fill={color}
      />
      <rect x="14" y="20" width="36" height="10" rx="2.5" fill={accent} />
      <rect x="16" y="38" width="8" height="4" rx="1" fill={accent} />
      <rect x="40" y="38" width="8" height="4" rx="1" fill={accent} />
    </svg>
  );
}

// Track going into perspective (wedge)
function TrackWedge({ w = 90, h = 36, color = T.turq }) {
  return (
    <svg width={w} height={h} viewBox="0 0 90 36" fill="none">
      <path d="M 4 34 L 38 8 L 52 8 L 86 34" stroke={color} strokeWidth="2.6" strokeLinecap="round" />
      <line x1="22" y1="22" x2="68" y2="22" stroke={color} strokeWidth="2.2" strokeLinecap="round" />
      <line x1="30" y1="16" x2="60" y2="16" stroke={color} strokeWidth="2.2" strokeLinecap="round" />
      <line x1="38" y1="10" x2="52" y2="10" stroke={color} strokeWidth="2.2" strokeLinecap="round" />
    </svg>
  );
}

// ─── Shared wordmark renderer ────────────────────────────────────────
function Wordmark({ size = 26, weightSpot = 700, weightRail = 500, hqColor = T.steel,
                    font = 'Inter, sans-serif', letterSpacing = -0.7, separator }) {
  return (
    <div style={{
      fontFamily: font, fontSize: size, letterSpacing, color: T.ink,
      lineHeight: 1, whiteSpace: 'nowrap',
    }}>
      <span style={{ fontWeight: weightSpot, color: T.ink }}>Spot</span>
      {separator}
      <span style={{ fontWeight: weightRail, color: T.ink }}>Rail</span>
      <span style={{ fontWeight: 500, color: hqColor, marginLeft: size * 0.3 }}>HQ</span>
    </div>
  );
}

// ─── 10 horizontal lockups ───────────────────────────────────────────

// 01 — Reference-true: full S-ribbon + train + ties mark, wordmark right
function Logo01h() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
      <SRibbon size={72} />
      <div>
        <Wordmark size={30} weightSpot={700} weightRail={500} />
        <div style={{
          fontFamily: 'Inter, sans-serif', fontSize: 10.5, fontWeight: 500,
          color: T.turq, letterSpacing: 2.4, marginTop: 8, textTransform: 'uppercase',
        }}>
          UK trainspotting · live
        </div>
      </div>
    </div>
  );
}

// 02 — Simplified: geometric S with a turquoise "spot" dot, wordmark
function Logo02h() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
      <SGeo size={60} />
      <Wordmark size={28} />
    </div>
  );
}

// 03 — S-ribbon inside a pill with an outline, strong presence
function Logo03h() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
      <div style={{
        width: 74, height: 74, borderRadius: 20,
        border: `1.5px solid ${T.turq}44`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: `${T.turq}0D`,
      }}>
        <SRibbon size={56} ties={false} />
      </div>
      <div>
        <Wordmark size={28} />
        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 11, fontWeight: 500,
                      color: T.steelDim, letterSpacing: 1.6, marginTop: 6 }}>
          spot · track · share
        </div>
      </div>
    </div>
  );
}

// 04 — Monoline S + train nose, wordmark w/ turquoise "Rail"
function Logo04h() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
      <SRibbon size={64} stroke={8} />
      <div style={{
        fontFamily: 'Inter, sans-serif', fontSize: 28, letterSpacing: -0.7,
        lineHeight: 1, color: T.ink,
      }}>
        <span style={{ fontWeight: 600 }}>Spot</span>
        <span style={{ fontWeight: 600, color: T.turq }}>Rail</span>
        <span style={{ fontWeight: 500, color: T.steel, marginLeft: 8 }}>HQ</span>
      </div>
    </div>
  );
}

// 05 — Split type: vertical bar separator, Space Grotesk
function Logo05h() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
      <SRibbon size={66} />
      <div style={{ width: 1, height: 44, background: `${T.steel}55` }} />
      <div style={{ fontFamily: '"Space Grotesk", Inter, sans-serif',
                    fontSize: 28, fontWeight: 500, color: T.ink,
                    letterSpacing: -0.7, lineHeight: 1 }}>
        Spot<span style={{ color: T.turq }}>-</span>Rail
        <span style={{ fontWeight: 700, marginLeft: 8 }}>HQ</span>
      </div>
    </div>
  );
}

// 06 — Train-nose only (simpler, scalable), wordmark right
function Logo06h() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
      <TrainNose size={52} />
      <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 28,
                    fontWeight: 600, letterSpacing: -0.7, color: T.ink, lineHeight: 1 }}>
        SpotRail<span style={{ color: T.turq, margin: '0 2px' }}>.</span>
        <span style={{ fontWeight: 500, color: T.steel }}>hq</span>
      </div>
    </div>
  );
}

// 07 — S-ribbon with a live "ping" badge, techy
function Logo07h() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
      <div style={{ position: 'relative' }}>
        <SRibbon size={68} />
        <span style={{
          position: 'absolute', top: 2, right: -2,
          width: 12, height: 12, borderRadius: '50%', background: T.turq,
          boxShadow: `0 0 0 4px ${T.turq}33, 0 0 12px ${T.turq}88`,
        }} />
      </div>
      <div>
        <Wordmark size={28} />
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6,
                      fontFamily: 'Inter, sans-serif', fontSize: 10, fontWeight: 700,
                      color: T.turq, letterSpacing: 2, marginTop: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: T.turq }} />
          LIVE · UK NETWORK
        </div>
      </div>
    </div>
  );
}

// 08 — Monoline minimal: thin-stroke S, monospace wordmark
function Logo08h() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
      <svg width="56" height="56" viewBox="0 0 64 64">
        <path
          d="M 54 20 C 54 13, 47 8, 38 8 L 22 8 C 14 8, 8 14, 8 22 C 8 30, 14 34, 22 34 L 42 34 C 50 34, 56 40, 56 48 C 56 55, 50 60, 42 60 L 14 60"
          stroke={T.turq} strokeWidth="3.5" fill="none" strokeLinecap="round"
        />
        {/* mini train terminus */}
        <rect x="46" y="4" width="14" height="8" rx="2" fill={T.turq} />
      </svg>
      <div style={{ fontFamily: '"IBM Plex Mono", ui-monospace, monospace',
                    fontSize: 22, fontWeight: 500, color: T.ink,
                    letterSpacing: -0.3, lineHeight: 1 }}>
        spot<span style={{ color: T.turq }}>_</span>rail
        <span style={{ color: T.steel, marginLeft: 6 }}>.hq</span>
      </div>
    </div>
  );
}

// 09 — S-ribbon with track-wedge beneath wordmark (horizon line)
function Logo09h() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
      <SRibbon size={70} />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        <Wordmark size={28} />
        <svg width="170" height="8" viewBox="0 0 170 8">
          <line x1="0" y1="2" x2="170" y2="2" stroke={T.turq} strokeWidth="1.3" />
          <line x1="0" y1="6" x2="170" y2="6" stroke={`${T.turq}66`} strokeWidth="1.3" />
        </svg>
      </div>
    </div>
  );
}

// 10 — Station-sign style: dark mark tile beside wordmark
function Logo10h() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
      <div style={{
        width: 78, height: 78, background: T.turq, borderRadius: 14,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <svg width="60" height="60" viewBox="0 0 72 72" fill="none">
          <path
            d="M 58 22 C 58 14, 48 10, 38 10 L 24 10 C 14 10, 8 16, 8 24 C 8 32, 14 36, 24 36 L 48 36 C 58 36, 64 40, 64 48 C 64 56, 58 62, 48 62 L 18 62"
            stroke={T.bg} strokeWidth="10" strokeLinecap="round"
          />
          <path
            d="M 44 6 L 44 18 C 44 22 48 24 52 24 L 62 24 C 66 24 68 21 68 17 C 68 12 64 6 58 6 Z"
            fill={T.bg}
          />
        </svg>
      </div>
      <div>
        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 30,
                      fontWeight: 700, letterSpacing: -0.9, color: T.ink, lineHeight: 1 }}>
          SpotRail
        </div>
        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 12,
                      fontWeight: 600, letterSpacing: 4, color: T.turq, marginTop: 8 }}>
          · HQ ·
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  T,
  SRibbon, SGeo, TrainNose, TrackWedge, Wordmark,
  Logo01h, Logo02h, Logo03h, Logo04h, Logo05h,
  Logo06h, Logo07h, Logo08h, Logo09h, Logo10h,
});
